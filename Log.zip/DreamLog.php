<!DOCTYPE html>
<html>
<head>
	<title>Dream Interpreter: Dream Log</title>	
	<link href="dream.css" rel="stylesheet" type="text/css"/>
	<style>
		td {
			width: 200px;
		}
	</style>
</head>

<body style="background-image:url(cloudpic.jpg); background-repeat: no-repeat; background-size: cover;" onload="checkCookie()">	
	<header>
		<nav class="horizontal">
			<ul>
				<a id ="logo" href="DreamInt.php">DI</a>
				<li><a href="DreamLog.php">View your dream log</a></li>
			</ul>
		</nav>
	</header>
	
	<?php include "Log.php"?>
	
	
</body>
</html>