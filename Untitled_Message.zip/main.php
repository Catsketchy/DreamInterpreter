
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="PHPstuff.php" method="POST">
	<fieldset>
			<label for="fname">First Name</label>
			<input type="text" name="fname" id="fname" />
			<label for="lname">Last Name</label>
			<input type="text" name="lname" id="lname" />
			<label for="email">Email Address</label>
			<input type="email" name="email" id="email" />
			<br>
			<select name="fav" id="fav">
				<option value="v2">#2 Jersey Shore Favorite</option>
				<option value="v3">#3 The American Classic</option>
				<option value="v5">#5 The Super Sub</option>
				<option value="v6">#6 Famous Roast Beef and Provolone</option>
				<option value="v7">#7 Turkey Breast and Provolone</option>
				<option value="v8">#8 Club Sub</option>
				<option value="v9">#9 Club Supreme</option>
				<option value="v10">#10 Tuna Fish</option>
				<option value="v13">#13 The Original Italian</option>
				<option value="v14">#14 The Veggie</option>
			</select>
			<p>
				<button type="submit" name="submit">Submit</button>
			</p>
		</fieldset>
</form>
<section>
	<h2>Results</h2>
	<p>
		<?php include 'PHPstuff.php';?>
	<h3>#2 Jersey Shore Favorite</h3><br>
	<?php  
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#3 The American Classic</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#5 The Super Sub</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#6 Famous Roast Beef and Provolone</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#7 Turkey Breast and Provolone</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#8 Club Sub</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#9 Club Supreme</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#10 Tuna Fish</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#13 The Original Italian</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	<h3>#14 The Veggie</h3><br>
	<?php 
		$sql="SELECT * FROM Reviews WHERE favorite='v2';";
		$result = mysqli_query($conn, $sql);
		if($result===FALSE)
		{
			$resultCheck = 0;
		}
		else
		{
			$resultCheck = mysqli_num_rows($result);
		}
		
		if($resultCheck > 0)
		{
			while($row = mysqli_fetch_assoc($result))
			{
				echo $row['email'] . "<br>";
			}
		}
		else
			echo "Nobody loves me.<br>";
	?>
	</p>
</section>
</body>
</html>
